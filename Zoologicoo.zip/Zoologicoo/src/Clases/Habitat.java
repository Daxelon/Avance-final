/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.awt.List;
import java.util.ArrayList;
import Jframes.*;
/**
 *
 * @author braya
 */
public class Habitat {
    private String nombre;
    private ArrayList<AnimalSalvaje> animalSal;
    private ArrayList<AnimalDomestico> animalDo;

    public Habitat() {
    }

    public Habitat(String nombre) {
        this.nombre = nombre;
        this.animalSal = new ArrayList<>();
        this.animalDo = new ArrayList<>();
    }

    public void AgAnimalSavaje(AnimalSalvaje animal){
    animalSal.add(animal);
    }
    
    public void AgAnimalDomestico(AnimalDomestico animal){
    animalDo.add(animal);
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<AnimalSalvaje> getAnimalSal() {
        return animalSal;
    }

    public void setAnimalSal(ArrayList<AnimalSalvaje> animalSal) {
        this.animalSal = animalSal;
    }

    public ArrayList<AnimalDomestico> getAnimalDo() {
        return animalDo;
    }

    public void setAnimalDo(ArrayList<AnimalDomestico> animalDo) {
        this.animalDo = animalDo;
    }
    // Instancias de hábitats
    public static final Habitat HABITAT1 = new Habitat("Terrestre F-5");
    public static final Habitat HABITAT2 = new Habitat("TERRESTRE A-3");
    public static final Habitat HABITAT3 = new Habitat("TERRESTRE G-4");
    public static final Habitat HABITAT4 = new Habitat("TERRESTRE G-3");
    
}
