/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author braya
 */
public class AnimalDomestico extends Animal {

    public AnimalDomestico() {
    }

    public AnimalDomestico(int id, int edad, String nameAnimal, String ownName, String habitat, char sex) {
        super(id,edad, nameAnimal, ownName, habitat, sex);
    }
    
    
}
